package practic.java;

/public class firstritik {
   // public static void printName(String name){
      //  System.out.println(name);
    //    return;

  //  public static void main(String args[]) {
        // System.out.print("HELLO JAVA I LOVE YOU");
        //VARIABLE
     /*   String name ="aman";
        int age = 265;
        System.out.print("age");
*/
        //if else condition
        /*
        int age = 89;
        if(age>18){
            System.out.print("this people can dom vote");

        }
        else{
            System.out.print("they can not do vote");
        }

         */
        //USER INPUTS

      /*  Scanner sc = new Scanner(System.in);
        String name = sc.nextLine() ;
        System.out.println(name);*/
      /*  Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b= sc.nextInt();
        int sum  = a+b;
        int difference = a-b;
        float divide = a/b;
        int mutiply = a*b;
        System.out.println(sum);
        System.out.println(difference);
        System.out.println(divide);
        System.out.println(mutiply);
*/
        // area of circle
        //Scanner sc = new Scanner(System.in);
        //for loop

/*float r = sc.nextFloat();
 double   area = 3.14*r;

 System.out.println(area);*/
       /* int m = sc.nextInt();
        for (int i = 1; i <=m; i++) {

            System.out.println(i);
        }*/
        //multiplaction table
  /*      int n = sc.nextInt();
        for(int i =1;10>=i;i++){
        System.out.println(n*i);
        }*/
       // do while loop
     /*  int i = sc.nextInt() ;
       do{
            System.out.println("the name of topper in the class is Mr.ritik meena");
        }while(i<85);
*/
        //FUNCTIONS

import java.util.Scanner;

public class firstritik {
    //  public static void printName(String name){
    //   System.out.println(name);
    // return;(RETURN ARE USE TO EXIT THE FUNCTION
    //  }
  public static int calculateSum(int a, int b){
       int sum = a+b;
       return sum;
   }
    public static void main(String arg[]){
     Scanner sc = new Scanner(System.in) ;
     int a = sc.nextInt() ;
     int b= sc.nextInt() ;
     int sum = calculateSum(a,b);
        System.out.println(sum);
    }
/*public static int multiplationIs(int a, int b) {
    int multiply = a * b;
    return multiply;
}
public static void main(String arg[]){


    Scanner sc = new Scanner(System.in);
    int a=sc.nextInt();
    int b=sc.nextInt() ;
    int multiply=a*b;
    System.out.println(multiply);
}*/
  /*  public static void printFactrioal(int a) {
        //loop
        int factrioal = 1;
        for (int i = a; i >= 1; i--) {
            factrioal = factrioal * i;
        }
        System.out.println(factrioal);
        return;
    }

    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();


        printFactrioal(a);
    }*/
    /*public static void printFactrioal(long a) {
        //loop
        long factrioal = 1;
        for (long i = a; i >= 1; i--) {
            factrioal = factrioal * i;
        }
        System.out.println(factrioal);
        return;
    }

    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextInt();


        printFactrioal(a);
    }
*/
}













