import java.util.*;
public class Function{
    public static void sum(int numb1,int numb2){
        int sum = numb1 + numb2 ;
        System.out.println(sum);
    }
    public static void main(String arg[])
    {
        Scanner sc=new Scanner(System.in);
        int numb1=sc.nextInt();
        int numb2=sc.nextInt();
       sum(numb1 ,numb2);
    }
}
