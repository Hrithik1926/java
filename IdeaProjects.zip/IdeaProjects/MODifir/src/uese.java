class Account{
    public String name;
    protected String email;
    protected int number;

    private String password;
    //getters and seters
    public String getPassword(){
      return  this.password;
    }
    public void setPassword(String password){
        this.password=password;

    }

}
public class uese {
    public  static void main(String arg[]){
        Account a1=new Account();
        a1.name="HRITIK MEENA";
        a1.email="meenaritik361@gmail.com";
        a1.number=98951151;
        a1.setPassword("Sjrr@1190");
        System.out.println(a1.getPassword());
    }
}
