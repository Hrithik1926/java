package java.first;

import java.util.Scanner;

public class programming {
    // System.out.print("HELLO JAVA ");//FIRST JAVA PROGRAM {JAVA IS THE CLASS BASED ,OBJECT ORIENTED PROGRAMMING LANGUAGE}
    //ALGEBRATIC SUM OF VARIABLE

    Scanner sc = new Scanner(System.in);
  /* String name =sc.nextLine() ;
   int a = sc.nextInt();
   int b = sc.nextInt();
    int sum=a+b;
    int multiply= a*b;
    float divide=a%b;
    float divid=a/b;

        int subtract=a-b;
        System.out.println(name);
        System .out.println(multiply);
        System .out.println(sum);
        System .out.println(divide);
        System .out.println(divid);
        System .out.println(subtract);*/
    //parameter and area of circle
       /* int r = sc.nextInt() ;
        double parameter = 2*3.14*r;
        double area = 3.14*r*r;
        System.out.println(parameter);
        System.out.println(area);*/
    //Table OF ANY NUMBER
     /*   int a = sc.nextInt();

        for (int i = 0; i <11; i++) {
           int n= i*a;
            System.out.println(n);

        }*/
    //   if --else CONDITIONS
       /* int age = sc.nextInt() ;
        if(age>=18){
            System.out.println("you ALLIGABLE TO DO VOTE");
        }
        else{
            System.out.println("you can not do vote");
        }
        if(age>=21){
            System.out.println("you alligable to do sadi");
        }
        else{
            System.out.println("you can not do sadi");
        }
        int X  = sc.nextInt() ;
        int Y = sc.nextInt() ;

        if(X>Y){
            System.out.println("X is greater then Y");
        } else if (X==Y) {
            System.out.println("X and Y are equal");
        }
            else {
                System.out.println("x is smaller then y");
            }

        */
//  SWITCH CASE
      /*  int months = sc.nextInt() ;
        switch (months){
            case 1:
                System.out.println("JANUARY");
                break;
            case 2:
                System.out.println("FEBARY");
                break;
            case 3:
                System.out.println("MARCH");
                break;
            case 4:
                System.out.println("APRIL");
                break;
            case 5:
                System.out.println("MAY");
                break;
            case 6:
                System.out.println("JUNE");
                break;
            case 7:
                System.out.println("JULY");
                break;
            case 8:
                System.out.println("AUGUST");
                break;
            case 9:
                System.out.println("SEPETEMBER");
                break;
            case 10:
                System.out.println("OCTOMBER");
                break;
            case 11:
                System.out.println("NOVERBER");
                break;
            case 12:
                System.out.println("DECEMBER");
                break;
            default :
                System.out.println("invalid number " + "it is invalid for months " );
                }

       */


// TYPE OF LOOP WE LEARNT ABOUT LOOP
        /*
        BASICALLY THERE ARE THREE TYPES OF LOOP
        1. FOR LOOP
        2. WHILE LOOP
        3.DO WHILE LOOP

         */
    //1. FOR LOOP
       /* int n=sc.nextInt() ;
        for(int i=0; i<n;i++){
            System.out.println("SJRR");
        }

        */
    /// FOR EVEN NUMBER
    //int n = sc.nextInt();
       /* for (int i = 0; i< n; i++) {
            if (i%2 == 0) {
                System.out.println(i);
            }

        }

        */
    //ODD NUMBER
      /*  for (int i = 0; i< n; i++) {
            if (i%2 != 0) {
                System.out.println(i);
            }

        }

       */
    //question of loop
       /* int a=sc.nextInt() ;
        if(a==1){
            int student_marks=sc.nextInt() ;

            do{
                System.out.println("this is good ");
            }while(student_marks >=90);

            do{
                System.out.println("this is good ");
            }while(student_marks >=60);


            do{
                System.out.println("you have to focus on your study ");
            }while(student_marks >=0);
            return ;
        }
else {
    System.out.println("stop");
}

        */
      /*  int n=sc.nextInt() ;
        for (int i = 0; i< n; i++) {
            if (i%i == 1) {
                System.out.println(i);
            }
else{
                System.out.println("not prime number");


            }
        }


       */
// PARTTENS BY LOOP(NESTEED LOOP ARE USEED IN IT )
     /*   int n=sc.nextInt() ;
        int m=sc.nextInt() ;
       for(int i=0; i<n;i++) {
           for(int j=0; j<m;j++){
               System.out.print('*');
           }
           System.out.println();
       }


      */
       /*
       int n = sc.nextInt();
        int m = sc.nextInt();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (i == 0 || i == n - 1 || j == 0 || j == m - 1) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }

            }
            System.out.println();
        }



        */
    //BOADER OF STAR
     /*
      int n = sc.nextInt();
        int m = sc.nextInt();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (i == 0 || i == n - 1 || j == 0 || j == m - 1) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }

            }
            System.out.println();
        }

      */
    //half praymid
      /*
      int n=sc.nextInt() ;
        for(int i=1; i<n;i++) {
            for(int j=1; j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }

       */

    // intverted of praymid
       /* int n=sc.nextInt() ;
        for(int i=n; i>=1;i--) {
            for(int j=1; j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }

        */
     /*   int n = sc.nextInt();
        int m = sc.nextInt();
        for(int i= 1;i<n;i++ ){
            for(int j= 1; j<m;j++){
                System.out.print("*");
            }
            System.out.println();
        }


      */

      /*  int n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j < n - i; j++) {
                System.out.print(" ");
            }
            for(int j=1; j <=i; j++){
                    System.out.print("*");
                }
            System.out.println();
            }

       */
       /*
        int m=sc.nextInt();
        for(int i=0;i<=m;i++){
            for(int j=0;j<=i;j++){
                System.out.print(j + " ");
            }
            System.out.println();
        }

        */
       /* int m=sc.nextInt();
        for(int i=m;i>=1;i--){
            for(int j=1;j<=i;j++){
                System.out.print(j + " ");
            }
            System.out.println();
        }

        */
      /*  int n=sc.nextInt() ;
        int numb=1;
        for(int i=1;i<=n;i++){
            for(int j=1;j<i;j++){
                System.out.print(numb+" ");
                numb++;
            }
            System.out.println();
        }

       */
       /* int n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                if ((i + j) % 2 == 0) {
                    System.out.print(1 + " ");
                } else {
                    System.out.print(0 + " ");
                }
            }
            System.out.println();
        }

        */
    //butterfly partten
      /*  int a = sc.nextInt();
        for (int i = 1; i <= a; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            //spaces
            int spaces=2*(a-i);
            for(int j=1;j<=spaces;j++){
                System.out.print(" ");
            }
            //2nd part ke star
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
        //lower part

        for (int i = a; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            //spaces
            int spaces=2*(a-i);
            for(int j=1;j<=spaces;j++){
                System.out.print(" ");
            }
            //2nd part ke star
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }

       *///ROMBUS PARTTENS
      /*  int n = sc.nextInt();
        for(int i=1;i<=n;i++) {
            //spaces
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= n; j++) {
                System.out.print("*");
            }

            System.out.println();

        }

       */
//pyramid PARTTEN/*
       /* int n=sc.nextInt();
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n-i;j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print(i +" " );
            }
            System.out.println();
        }

        */
//palindronic partten
     /*   int n=sc.nextInt();
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n-i;j++){
                System.out.print(" ");
            }
            for(int j=i;j>=1;j--){
                System.out.print(j);
            }
            for(int j=2;i>=j;j++){
                System.out.print(j);
            }
            System.out.println();
        }

      */
       /* int n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
            for (int i = n; i >= 1; i--) {
                for (int j = 1; j <= n - i; j++) {
                    System.out.print(" ");
                }
                for (int j = 1; j <= 2 * i - 1; j++) {
                    System.out.print("*");
                }

                System.out.println();
            }

        */

}







