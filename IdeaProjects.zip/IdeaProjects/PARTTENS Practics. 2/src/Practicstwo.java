import java.util.*;
public class Practicstwo {
    public static void String(String name){
        System.out.println(name);
        return;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //  int n = sc.nextInt();
        //  int m = sc.nextInt();
       /* for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                System.out.print('*');
            }
            System.out.println( );
        }

        */
       /* for(int i=0;i<=n;i++){
            for(int j=0;j<=i;j++){
                System.out.print('*');
            }
            System.out.println( ' ');
        }
        for(int i=0;i<=n;i++){
            for(int j=0;j<=n;j++){
                System.out.print('*');
            }
            System.out.println( ' ');
        }

        */
        //SAME ROWS AND SAME COLUMS BY ONE INTPUT

      /*  int n=sc.nextInt() ;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                System.out.print('*');
            }
            System.out.println( ' ');
        }

       */
        //DIFFERENT ROWS AND  COLUMS BY TWO OR MORE INTPUT
     /*   int n=sc.nextInt() ;
        int m=sc.nextInt() ;

       for(int i=0; i<n;i++) {
            for(int j=0; j<m;j++){
                System.out.print('*');
            }
            System.out.println();
        }

      */
        //BOARDER OF * WITH THE HELP OF LOOPS AND IF-ELSE CONDITION

        /*int n=sc.nextInt() ;
        int m=sc.nextInt() ;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                if(i==0||i==n-1 || j==0 ||j==m-1){
                    System.out.print('*');
                }
                else{
                    System.out.print(' ');
                }
            }
            System.out.println();
        }

         */
//HAIF PRIMAID
        /*
int n=sc.nextInt();
for(int i=0;i<n;i++){
    for(int j=0;j<=i;j++){
        System.out.print("*");

    }
    System.out.println();
}
//INVERTED PYRAMID

        for(int i=n;i>=1;i--) {
            for (int j = 0; j <= i; j++) {
                System.out.print("*");

            }
            System.out.println();
        }

         */
       /* int n=sc.nextInt();
        for(int i=0;i<n;i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print("*");

            }
            System.out.println();
        }
        for(int i=n;i>=1;i--) {
            for (int j = 0; j <= i; j++) {
                System.out.print("*");

            }
            System.out.println();
        }

            //  int n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for(int j=1; j <i; j++){
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i =n; i >1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for(int j=1; j <i; j++){
                System.out.print("*");
            }
            System.out.println();
        }

        */
        //PRINT THE SAME NUMBER IN ROWS
     /*   int m=sc.nextInt();
        for(int i=1;i<=m;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j + " ");
            }
            System.out.println();
        }


      */
        //PRINT THE SAME NUMBER IN ROWS in inverted form
    /*   int n=sc.nextInt();
       for(int i=n;i>0;i--){
           for(int j=0;j<i;j++){
               System.out.print(j +" ");
           }
           System.out.println();
       }

     */
        //number in sequence
      /*  int n=sc.nextInt();
int nimb=1;
for(int i=0;i<=n;i++){
    for(int j=0;j<=i;j++){
        System.out.print(nimb+" ");
        nimb++;
    }
    System.out.println("");
}

       */
        /////playing with number
/*int n=sc.nextInt();
for(int i=1;i<n;i++){
    for(int j=0;j<i;j++){
        if((i+j)%2==0){
            System.out.print(1 +" ");
        }
        else{
            System.out.print(0 +" ");
        }
    }
    System.out.println();

}

        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++){
                if((i+j)%2==0){
                    System.out.print(1 +" ");
                }
                else{
                    System.out.print(0 +" ");
                }
            }
            System.out.println();

        }
        for(int i=n;i>=1;i--){
            for(int j=0;j<i;j++){
                if((i+j)%2==0){
                    System.out.print(1 +" ");
                }
                else{
                    System.out.print(0 +" ");
                }
            }
            System.out.println();

        }
        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++){
                if((i+j)%2==0){
                    System.out.print(1 +" ");
                }
                else{
                    System.out.print(0 +" ");
                }
            }
            System.out.println();

        }
        for(int i=n;i>=1;i--){
            for(int j=0;j<i;j++){
                if((i+j)%2==0){
                    System.out.print(1 +" ");
                }
                else{
                    System.out.print(1+" ");
                }
            }
            System.out.println();

        }
//ADVANCE * SOLUTIONS
/*
 //upper part of Butterfully
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            //space
            int space = 2 * (n - i);
            for (int j = 0; j < space; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        //Lower part of the Butterfully
        for (int i = n; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            int space = 2 * (n - i);
            for (int j = 0; j < space; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < i; j++) {
                System.out.print("*");

            }
            System.out.println();
        }
        Rombus
        int m = sc.nextInt();
        for (int i = 0; i <= m; i++) {
            for (int j = 0; j < m - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j <= m; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        int o = sc.nextInt();
        for (int i = 0; i < o; i++) {
            for (int j = 0; j < o - i; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < i; j++) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
       int o = sc.nextInt();
        for (int i = 0; i < o; i++) {
            for (int j = 0; j < o - i; j++) {
                System.out.print(" ");
            }
            for (int j = i; j > 1; j--) {
                System.out.print(j);

            }
            for (int j = 2; i > j; j++) {
                System.out.print( j);
            }
            System.out.println();
        }
       // int n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }

            System.out.println();
        }
    }

}
}
}
 */