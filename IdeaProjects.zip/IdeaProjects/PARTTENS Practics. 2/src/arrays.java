//import java.util.*;
public class arrays {
    public static void main(String args[]){
       // Scanner sc=new Scanner(System.in);
      int[] numb=new int[5] ;
        numb[0]=56;
        numb[1]=45;
        numb[2]=15;
        numb[3]=79;
        numb[4]=122;
        System.out.println(numb[0]);
        System.out.println(numb[1]);
        System.out.println(numb[2]);
        System.out.println(numb[3]);
        System.out.println(numb[4]);
    }
}
