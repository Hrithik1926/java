import java.util.*;
public class functions {
    //decelar the function

    /*public static void printname(String name){
        //perform the task
        System.out.println(name);
        return ;
    }


    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String name=sc.nextLine();
        //call the funtion
        printname(name);


    }
}

     */
 /*   public static int additn(int s,int p){
        int add=s+p;
        return add;
    }
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int s=sc.nextInt();
        int p=sc.nextInt();
        int add=additn(s,p);
        System.out.println(add);
    }

  */
   /* public static void num(int a,int b){
        int num=a+b;
        System.out.println(num);
    }
public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        num(a,b);
    }

    */
    public static int calculateSum(int a,int b){
        int sum=a+b;
        return sum ;
    }
    public static void main(String arg[]){
        Scanner sc =new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sum=calculateSum(a,b);
        System.out.println(sum);
    }

}


