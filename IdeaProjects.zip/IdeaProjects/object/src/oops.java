class Cow {
    int age;
    String name;
    int legs;

    public void milk() {
        System.out.println("cow gives milk");
        System.out.println("the name of cow is :" + this.name);
        System.out.println("the legs of cow is :" + this.legs);
        System.out.println("the age of cow is :" + this.age);

    }

   /*
   //NON- PARAMETERIZED CONSTRUCTER

   Cow(){
    }
    public class oops {
    public static void main(String arg[]){
        Cow cow1=new Cow();
        cow1.name="rohiydhi";
        cow1.legs= 4;
        cow1.age= 12;
        Cow cow2=new Cow();
        cow2.name="somya";
        cow2.legs= 4;
        cow2.age= 22;
        cow1.milk();
        cow2.milk();

    }
}


    */
// PARAMETERIZED CONSTRUCTER

    /*
    Cow(String name,int age,int legs){

        this.name=name;
        this.age=age;
        this.legs=legs;
    }



}
public class oops {
    public static void main(String arg[]){
        Cow cow1=new Cow("monjlika",24,4);
        cow1.name="rohiydhi";
        cow1.legs= 4;
        cow1.age= 12;

        Cow cow2=new Cow("mayabati",22,4);
        cow2.name="somya";
        cow2.legs= 4;
        cow2.age= 22;
        cow1.milk();
        cow2.milk();


cow1.milk();
cow2.milk();
    }
}
*/
/*public class oops {
    public static void main(String arg[]){
        Cow cow1=new Cow("monjlika",24,4);
        cow1.name="rohiydhi";
        cow1.legs= 4;
        cow1.age= 12;

        Cow cow2=new Cow("mayabati",22,4);
        cow2.name="somya";
        cow2.legs= 4;
        cow2.age= 22;
        cow1.milk();
        cow2.milk();


cow1.milk();
cow2.milk();
    }
}
*/

    // COPY RIGHT CONSTRUCTER
    Cow(Cow cow2) {
        this.name = cow2.name;
        this.age = cow2.age;
        this.legs = cow2.legs;

    }
    Cow(){

    }

    public class oop {
        public static void main(String arg[]) {
            Cow cow1 = new Cow ();
            cow1.name = "rohiydhi";
            cow1.legs = 4;
            cow1.age = 12;
            Cow cow2 = new Cow(cow1);
            cow2.milk();

        }
    }
}




