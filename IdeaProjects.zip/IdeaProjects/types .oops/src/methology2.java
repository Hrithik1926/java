class Shape {
    public void area(){
        System.out.println("the area of shape");
    }
}
class Tringle extends Shape{
    public void area(int h,int b) {
        System.out.println(2*h*b);

    }
}
class Circle extends Shape{
    public void area(int r) {
        System.out.println(3.14*r*r);

    }
}

public class methology2 {
    public static void main(String arg[]){
        Tringle t1=new Tringle();

    }
}
