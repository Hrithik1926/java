////compilr time polymerphism
class Student{
    String name;
    int age;


    public void showsinformation(String name)
    {
        System.out.println(name);
    }
    public void showinformation(int age){

        System.out.println(age);
    }

    public void showinformation(String name,int age){
        System.out.println(name);
        System.out.println(age);
    }
}
public class methology {
    public static void main(String arg[]){
        Student s1=new Student();
        s1.name="THE HRITIK";
        s1.age=20;
        s1.showinformation(s1.name,s1.age);
    }
}
