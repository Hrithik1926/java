package uses.of;
class Account{
    public String name;
    protected int number;
    protected String email;
    private String Password;
    public void SetPassword(String Password){
        this.Password=Password;

    }

    }

public class modifier {
    public static void main(String arg[]){
        Account a1= new Account();
        a1.name="HRITIK";
        a1.email="meenaritik361@gmail.com";
        a1.number=9891151;
        a1.SetPassword("Sjrr@1190");
    }
}
