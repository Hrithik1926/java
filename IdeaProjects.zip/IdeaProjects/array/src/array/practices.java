package array;
import java.util.*;
/*
public class practices {

    public static void main(String arg[]) {
        //  int[]marks=new int[3];
        //  1. method
        //  int marks[]=new int[3];
        //2.method
        // int marks[] = {54, 545, 8, 545, 878};
        //  marks[0]=99;
        //  marks[1]=98;
        //  marks[2]=99;
        // System.out.println(marks[0]);
        // System.out.println(marks[1]);
        // System.out.println(marks[2]);
        //  for (int i = 0; i < 5; i++) {
        //   System.out.println(marks[i]);
      /*  Scanner sc=new Scanner(System.in);//array input
        int size=sc.nextInt();
        int parrts[]=new int[size];
        //intput
        for(int i=0;i<size;i++){
            parrts[i]=sc.nextInt();
        }
        int x=sc.nextInt();
      //output//parrts.length==size
        for(int i =0;i<parrts.length;i++){
            if(parrts[i]==x){
                System.out.println("x found atplace:"+i);

       */

      /*   Scanner sc=new Scanner(System.in);
         int size= sc.nextInt();
         int number[]=new int[size];
         for(int i=0;i<size;i++){
             number[i]=sc.nextInt();
         }
         //for intput number
        for(int i=0; i<number.length; i++) {
            System.out.println(number[i]+" ");
        }

       */
        //input user
      /*  Scanner sc= new Scanner(System.in);
        int size=sc.nextInt();
       int[] safari=new int[size] ;
       for(int i=0;i<size;i++){
           safari[i]=sc.nextInt();
       }
       for(int i=0;i<safari.length;i++){
           System.out.println(safari[i]);
       }

       */
       /* Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        int x = sc.nextInt();

        int[] safari = new int[size];
        for (int i = 0; i < size; i++) {
            safari[i] = sc.nextInt();
        }
        for (int i = 0; i < safari.length; i++) {
            if (safari[i] == x) {
                System.out.println("the x found at :"+i);
            }

        */
        //2D array
   /*     Scanner sc = new Scanner(System.in);
        int rows = sc.nextInt();
        int colums = sc.nextInt();
        int[][] sampile = new int[rows][colums];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < colums; j++) {
                sampile[i][j] = sc.nextInt();
            }
       for(i = 0; i< sampile.length; i++) {
                for (int j = 0; j < sampile.length; j++) {

                    System.out.println(sampile[i][j] + "");

                }
                System.out.println();
            }
        }

    }
}
/*class Pen {//class decleraction
    String colour;//propertyes
    String type;
    public void write(){
        System.out.println("writing something");
    }//method
}
public class OOPS {
    public static void main(String arg[]){
        Pen pen1=new Pen();
        pen1.colour="blue";
                pen1.type="gel";
                pen1.write();
    }
    }

 */
      class Cow{//CLASS DECLERACTION
          String age;//PROPERTY
          String legs;
          String name;
          public void run(){//METHOD OF CLASS (FUNCTION)
              System.out.println("THE COW IS RUN VERY FAST");
          }
          public class array{
              public static void main (String arg[]){
                  Cow cow1= new Cow();
                  cow1.age= "12";
                  cow1.legs= "4";
                  cow1.name= "SHILA";
                  cow1.run();
              }
          }

      }











