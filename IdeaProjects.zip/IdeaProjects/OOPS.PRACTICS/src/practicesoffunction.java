import java.util.*;
class practicesoffunction{
    int age ;
    String name;
    String sub;
    static void School(){
        String name="KVD";
        int Standard=9;
    }
    public static void main(String[] args){
        Scanner sc =new Scanner(System.in);
        int age =sc.nextInt();
        String name=sc.nextLine;
        String sub=sc.nextline;
        Information();
    }
}


