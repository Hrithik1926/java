/*class Pen {//class decleraction
    String colour;//propertyes
    String type;
    public void write(){
        System.out.println("writing something");
    }//method,function.
}




public class OOP{
    public static void main(String arg[]){
        Pen pen1=new Pen();
        pen1.colour="blue";
                pen1.type="gel";
                pen1.write();
    }


    }



 */


class Cow{//CLASS DECLERACTION
    String age;//PROPERTY
    String legs;
    String name;
    public void run(){//METHOD OF CLASS (FUNCTION)
        System.out.println("THE COW IS RUN VERY FAST");
    }
    public class OPP{
        public static void main (String arg[]){
            Cow cow1= new Cow();
            cow1.age= "12";
            cow1.legs= "4";
            cow1.name= "SHILA";
            cow1.run();
        }
    }

}




