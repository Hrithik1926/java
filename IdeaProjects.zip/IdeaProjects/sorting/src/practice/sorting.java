package practice;

public class sorting {
    public static void pritArray(int array[]){
        for(int i=0;i< array.length;i++){
            System.out.print(array[i]+" ");

        }
        System.out.println();
    }
    public static void main(String args[]){
        int array[]={23,59,59,497,5649,44,4484,5,4678};
        // bubble sort
for (int i=0;i<array.length-1;i++){
    for (int j=0;j<array.length-i-1;j++){
        if (array[i]>array[i+1]){
            //swap
            int arr;
            arr=array[j];
            array[j]=array[j+1];
            array[j+1]=arr;
        }
    }
}
        pritArray(array);
    }

}
