public class sorting3 {
    public static void printSumura(int array[]){
        for (int i=0;i< array.length;i++){
            System.out.print(array[i]+" ");
        }
        System.out.println();
    }
    public static void main(String args[]){
        int sumura[]={45,78,523,897,645,63,784,9,35,6454,79,4,406,454,649,468,410,936565868,65,65,};
      for (int i=0;i<sumura.length-1;i++) {
          for (int j=0; j<sumura.length-i-1;j++){
              if (sumura[j]>sumura[j+1]){
                  int radhe=sumura[j];
                  sumura[j]=sumura[j+1];
                  sumura[j+1]=radhe;
              }
          }
      }
      printSumura(sumura);
    }
}
