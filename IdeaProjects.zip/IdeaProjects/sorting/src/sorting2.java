public class sorting2 {
    public static void printArray(int array[]){
        for (int i=0;i<array.length;i++){
            System.out.print(array[i]+" ");
        }
        System.out.println();

    }
    public static void main(String args[]){
        int array[]={1,2,3,4,5,6,7,8,9,1,22,34,54,67,54,23,89,675};
        for (int i=0;i<array.length-1;i++){
            for (int j=0;j< array.length-i-1;j++){
                if (array[j]>array[j+1]){
                    int temp;
                    temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;

                }
            }
        }
printArray(array);
    }
}
