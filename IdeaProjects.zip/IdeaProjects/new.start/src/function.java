import org.w3c.dom.ls.LSOutput;

import java.util.*;
public class function {
    /* public static void printMyName(String name){
         System.out.println(name);
         return;
     }
     public static void main(String args[]){
         Scanner sc =new Scanner(System.in);
         String name= sc.nextLine();
         printMyName(name);//FUNCTION CALL

     */
    //TO FUNCTION ADD THE NUMBER IN  FUNCTION
/*public static int calculateSum(int a,int b){
    int sum=a+b;
    return sum ;
}
public static void main(String arg[]){
    Scanner sc =new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int sum=calculateSum(a,b);
    System.out.println(sum);
    }

 */
    //MULTIPLY
    /*
public static int multiply(int a,int b){
    int numb= a*b;
    return numb;
}
public static void main(String arg[]){
    Scanner sc=new Scanner(System.in);
    int a=sc.nextInt();
    int b=sc.nextInt();
    int numb=multiply(a,b);
    System.out.println(numb);


}

     */
    //SUBTRACTION
  /* public static int calculatesubtraction(int a,int b){
       int numb=a-b;
       return numb ;
   }
    public static void main(String arg[]){
        Scanner sc =new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int numb=calculatesubtraction(a,b);//CALL OF FUNCTION
        System.out.println(numb);
    }

   */
    //factriol function
  /*  public static int factriol(int n) {
        int permitation = 1;
        for (int i = n; 1 <= i - 1; i--) {
            permitation= permitation*i;
        }
        System.out.println(permitation);
        return 1;
    }
    public static void main(String arg[]){
        Scanner sc =new Scanner(System.in);
        int n=sc.nextInt();
        factriol(n);

    }

   */
    //function on even or odd number

    /*public static int myeven(int n) {
    if ( n%2==0) {
        System.out.println("even");
    } else{
        System.out.println("not even ");
    }

    return 1;
}
public static void main(String arg[]){
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    myeven(n);
}

     */
    //MY TABLE
  /*
    public static int myTable(int n){
        for(int i=1;i<=10;i++){
            System.out.println(i*n);
        }
        return 1;
    }
    public static void main(String arg[]){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        myTable(n);
    }

   */
    int []marks={454,54548,5989};
    System.out.println(marks);


}

