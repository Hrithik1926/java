public class Main {
   public void myFunction(){
        System.out.println("Hello Java I am Hritik Meena");
      //  return;
    }
    public static void main(String[] args)
    {
       Main muObj=new Main();
        System.out.println("Hello world!");
        muObj.myFunction();
    }


  /*  static void myFuntion(){
        System.out.println("Hello Java I am Hritik Meena");

    }

    public static void main(String[] args) {
myFuntion();
    }

   */
}
