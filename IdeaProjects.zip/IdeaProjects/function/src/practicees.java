import java.util.*;
public class practicees {
    /* public static void add(int a,int b){
         int sum=a+b;
         System.out.println(sum);
     }
     public static void main(String args[]){
         Scanner sc=new Scanner(System.in);
         int a=sc.nextInt();
         int b=sc.nextInt();
         add(a,b);
     }

     */
//MULTIPLY
 /*public static void multiply(int s,int p){
     int multi=s*p;
     System.out.println(multi);
 }
 public static void main(String args[]){
     Scanner sc=new Scanner(System.in);
     int s= sc.nextInt();
     int p= sc.nextInt();
     multiply(s,p);
 }

  */
    //NUMBER TABLE
 /*   public static void table(int n) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i * n);
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        table(n);
    }

  */
    //FRACTIJECTION
  /*  public static int numb(long n){
        long fact=1;
        for(long i=n;0<=i-1;i--){
             fact=fact*i;
    }
        System.out.println(fact);

        return 1;

    }
public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    long n=sc.nextInt();
    numb(n);
    }
}




   */


}