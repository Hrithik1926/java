

/*import java.util.Scanner;
public class recursion {

    public static int factriol(int n){
        if(n==0||n==1){
            return 1;
        }
        else{
            return n*factriol(n-1);
        }
    }
    public static void main(String arg[]){
        Scanner sc = new Scanner(System.in);
        int n= sc.nextInt();


        System.out.println(factriol(n));
    }
}

 */
