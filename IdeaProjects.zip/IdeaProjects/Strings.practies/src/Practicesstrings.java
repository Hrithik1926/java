import java.util.*;
public class Practicesstrings {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
       /*
        //This is only for name printing
        String firstName=sc.nextLine();
        String lastName=sc.nextLine();
        String fullName=firstName+" "+lastName;
        //System.out.println(firstName+" "+lastName);
        System.out.println(fullName);

        */
        //length Keyword are used for count the number of words
      /*  String firstName=sc.nextLine();
        String lastName=sc.nextLine();
        String fullName=firstName+" "+lastName;
        System.out.println(fullName.length());

       */
        //
    /*    String firstName=sc.nextLine();
        String lastName=sc.nextLine();
        String fullName=firstName+" "+lastName;
        for(int i=0;i<fullName.length().;i++){
            System.out.println(fullName.charAt(i));


        }

     */
        //SUB Strings
  //  String myName=sc.nextLine();
     //   System.out.println(myName.substring(0,15));
        //ParseInt Method of integer class(it's used to store the int value in string)
        // String myName="3224";
    //     int number=Integer.parseInt(myName);
        //System.out.println(number);
//tostring(it's used to convert the int value in String)
      /*  int nmb=46546;
        String str=Integer.toString(nmb);
        System.out.println(str);
        //System.out.println(str.charAt();
        System.out.println(str.length());

       */
        //String Builder
        //Print name in string builder
       /* StringBuilder name=new StringBuilder("HRITIK MEENA");
        System.out.println(name);

        */
        //to know the the vlaue of String character we use the
        //charat() key word
     /*   StringBuilder myName= new StringBuilder("hritik");
        System.out.println(myName.charAt(2));

      */
        //to add the new char be use key word (insret)
     /*   StringBuilder myName= new StringBuilder("hritik");
        myName.insert(0,'H');
        System.out.println(myName);

      */
        //to delete the  char be use key word (insret)
       /* StringBuilder myName= new StringBuilder("hritik");
        myName.delete(0,1);
        System.out.println(myName);

        */
        //APPEND means add something at the end
        /*StringBuilder myName= new StringBuilder("hritik");
        myName.append( "meena");
        System.out.println(myName +" ");
        System.out.println(myName.length());

         */
        StringBuilder myName= new StringBuilder("hritik");
        for(int i=0;i<myName.length()/2;i++){
            int fornt=i;
            int back=myName.length()-i-1;
            char forntchar=myName.charAt(fornt);
            char backchar=myName.charAt(back);
            myName.setCharAt(fornt,backchar);
            myName.setCharAt(back,forntchar);
        }
        System.out.println(myName);

    }
}
