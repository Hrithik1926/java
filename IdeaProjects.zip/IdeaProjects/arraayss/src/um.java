import java.util.*;
public class um {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int size = sc.nextInt();
        int[] abc = new int[size];
        for( int i=0; i<=size; i++){
            abc[i]= sc.nextInt();
        }
        for(int i=0; i<=size; i++){
            System.out.print(abc[i]+" ");
        }
        System.out.println();
    }

}
