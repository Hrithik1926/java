import java.util.*;
public class again {
    public static void main(String[] args) {
       /* int[] ritik=new int[5];

        ritik[0]=45;
        ritik[1]=56;
        ritik[2]=485;
        ritik[3]=475;
        ritik[4]=4578;
        System.out.print(ritik[0]+" ");
        System.out.print(ritik[1]+ " ");
        System.out.print(ritik[2]+" ");
        System.out.print(ritik[3]+" ");
        System.out.println(ritik[4]+" ");

        */
/*Scanner sc=new Scanner(System.in);
int size=sc.nextInt();
String names[]=new String[size];
for(int i=0;i<size;i++){
    names[i] =sc.nextLine();
}
for(int i=0;i<names.length;i++){
    System.out.println(names[i]);

}

 */
     /*   Scanner sc=new Scanner(System.in);
        int size=sc.nextInt();
        int names[]=new int[size];
        for(int i=0;i<size;i++){
            names[i] =sc.nextInt();
        }
        for(int i=0;i< names.length;i++){
            System.out.println(names[i]);

        }

      */
  /*  String nam[]={
            "THE","tha","THEN","they"
    };
        System.out.println(nam[0]);
        System.out.println(nam[1]);
        System.out.println(nam[2]);
        System.out.println(nam[3]);

   */
        Scanner sc=new Scanner(System.in);
        int rows=sc.nextInt();
        int colums=sc.nextInt();
        int nothing[][]=new int[rows][colums];
        for(int i=0;i<rows;i++){
            for(int j=0;j<colums;j++){
                nothing[i][j]=sc.nextInt();

            }

        }
        for (int i=0;i<rows;i++)  {
            for (int j=0;j<colums;j++){
                System.out.print(nothing[i][j]+" ");
            }
            System.out.println();
        }


    }
}
