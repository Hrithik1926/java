import java.util.*;
public class practics {
    public static void main(String args[]) {
        //first method
     /*  int[] numb=new int[3];
         numb[0]=45;
        numb[1]=45245;
        numb[2]=41125;

        System.out.println(numb[0]);
        System.out.println(numb[1]);
        System.out.println(numb[2]);

      */


//2.method of array
    /*    int[] marks = {454, 58, 84, 45, 45};
        System.out.println(marks[0]);
        System.out.println(marks[1]);
        System.out.println(marks[2]);
        System.out.println(marks[3]);
        System.out.println(marks[4]);
        System.out.println(marks[5]);

     */
        /*
//3.method of array
        Scanner sc = new Scanner(System.in);
//number.length==size
//length is used for find the length of array
        int size = sc.nextInt();
        int number[] = new int[size];
        for (int i = 0; i < size; i++) {
            number[i] = sc.nextInt();

        }
        for (int i = 0; i < size; i++) {
            System.out.print(number[i] + " ");
        }
        System.out.println();
    }
}

         */






      /*  Scanner sc=new Scanner(System.in);
        int rows=sc.nextInt();
        int colums=sc.nextInt();
        int [][] firsttwod=new int[rows][colums];
        for(int i=0;i<rows;i++){
            for (int j=0; j<colums;j++){
                firsttwod[i][j]=sc.nextInt();

            }

        }
        for (int i =0;i<firsttwod.length;i++){
            for (int j=0;j<firsttwod.length;j++){
                System.out.println(firsttwod[i][j]+" ");
            }


        }

       */

 /*   Scanner sc= new Scanner(System.in);
    int size=sc.nextInt();
    int numbera[]=new int[size];
    for (int i=0;i<size;i++){
        numbera[i]=sc.nextInt();
    }
    for (int i=0;i<numbera.length;i++){
        System.out.print(numbera[i] + " ");
    }
        System.out.println();
    }
}
*/
        //2D ARRAY
 /*       Scanner sc=new Scanner(System.in);
                int rows =sc.nextInt();
                int colums=sc.nextInt();
                int TwoD[][]=new int[rows][colums];
                for (int i=0;i<rows;i++) {
                    for (int j = 0; j < colums; j++) {
                        TwoD[i][j] = sc.nextInt();
                    }
                }
                for(int i=0;i<rows;i++){
                    for (int j=0;j<colums;j++){
                        System.out.print(TwoD[i][j]+" ");

                    }
                    System.out.println();

                }

  */

            }
        }
