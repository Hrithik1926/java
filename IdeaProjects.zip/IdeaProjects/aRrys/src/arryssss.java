import java.io.OptionalDataException;
import java.util.*;
public class arryssss {
    public static voi
}
