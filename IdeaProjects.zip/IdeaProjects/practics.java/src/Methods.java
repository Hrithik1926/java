import java.util.*;
public class Methods {
    public static void voterList(int age){
        if (age>=18){
            System.out.println("You are Alligable to do Vote");
        } else if (age<12) {
            System.out.println("You are Child.You can't do Vote");

        }
        else{
            System.out.println("You are not Alligable to do Vote.You are Teenager");
        }
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int age=sc.nextInt();
        voterList(age);

    }
}
