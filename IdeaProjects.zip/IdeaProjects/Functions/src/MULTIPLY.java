import java.util.Scanner;

class Function{

        /* public static void sum(int a,int b){
             int sum= a + b;
             System.out.println(sum);
     }
     public static void main(String arg[]){
         Scanner sc=new Scanner(System.in);
         int a=sc.nextInt();
         int b=sc.nextInt();
         sum(a,b);//FUNCTION CALL

         */
        public static int multiply(int a,int b){
            return a*b;
        }
        public static void main(String arg[]){
            Scanner sc=new Scanner(System.in);
            int a=sc.nextInt();
            int b=sc.nextInt();
            int product ;
           product= multiply(a,b);//FUNCTION CALL
        }
    }


