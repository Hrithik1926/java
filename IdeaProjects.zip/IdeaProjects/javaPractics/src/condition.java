import java.util.*;
public class condition {
    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
       /* char amit;
        char anil;
        amit=45;
        anil=243;
        int age1=sc.nextInt();
        int age2=sc.nextInt();
        if(45==243){
            System.out.println("they have equal money");
        }
        else{
            System.out.println("they have no equal money");
        }
        if(age1>age2){
            System.out.println("anil is younger then amit");
        }
        else{
            System.out.println("amit is eailder then anil");
        }

        */
     /*   int n=sc.nextInt();
        if(n%2==0){
            System.out.println("it is a positive number");
        }
        else{
            System.out.println("it is not positive number ");
        }

      */

    /*    System.out.print("the value of n is:");
        int n= sc.nextInt();
        if(n>0){
            System.out.println("it is a positive nunber");
        }
        else{
            System.out.println("not positive number");
        }

     */
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        int n3 = sc.nextInt();
        String largest;
        if (n1 > n2 ||n1 > n3) {
            largest=n1;
        } else if (n2>n1||n2 > n3) {
        largest=n2;
        } else if (n3 > n1||n3>n2) {
         largest=n3;
        }
        System.out.println("largest");


    }
}

        //SWITCH STATEMENT
       /* int m= sc.nextInt();
        switch (m){
            case 1:
                System.out.println("monday");
                break;
            case 2:
                System.out.println("tuesday");
                break;
            case 3:
                System.out.println("wednesday");
                break;
            case 4:
                System.out.println("thursday");
                break;
            case 5:
                System.out.println("friday");
                break;
            case 6:
                System.out.println("saturday");
                break;
            case 7:
                System.out.println("sunday");
                break;
        }

        */









