import java.util.*;
public class addvaroables {
    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        /*int a = sc.nextInt();
        int b =sc.nextInt();
        int r=sc.nextInt();
        int h=sc.nextInt();
        int sum= a+b;
        long multiply=a*b;
        float diivide=a/b;
        int reminder=a%b;
      int   subtract=a-b;
      System.out.println(sum);
        System.out.println(subtract);
        System.out.println(diivide);
        System.out.println(reminder);
        System.out.println(multiply);
        //area of circle
        //2*3.14*r*r;
        double area=(2*3.14*r*r);
        System.out.println(area);
        //area of triangle
        //1/2*b*h
        double triangle=(1/2)*b*h;
        System.out.println(triangle);
    }

         */
        //table
        int a = sc.nextInt();
        for (int i = 1; i < 11; i++) {


            System.out.println(i*a);
            System.out.println("i love you java");
        }
    }
}

