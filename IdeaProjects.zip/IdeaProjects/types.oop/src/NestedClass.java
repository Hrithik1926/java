 class Outerclass{
    String name="Hritik";
    class Inner{
        int age=15;
    }
}
public class NestedClass {
    public static void main(String[] args) {
        Outerclass obj1=new Outerclass();
        Outerclass.Inner obj2=obj1.new Inner();
        System.out.println(obj1.name);
        System.out.println(obj2.age);
        System.out.println(obj1.name);
        System.out.println(obj2.age);
    }
}
