public class Main {
   private String Name="Hritik Meena";
   public String getName(){
       return Name;
   }
}