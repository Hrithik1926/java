public class practices {
    int legs;
    int ear;
    int nose;
    public void eat(){
        System.out.println("cow eat grass ");
    }

    public static void main(String[] args) {

    }
}
