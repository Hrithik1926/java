public class OOOps {

    int legs;
    int ear;
    int nose;
    public void eat(){
        System.out.println("cow eat grass ");
    }
    public void print(){
        System.out.println(this.ear);
        System.out.println(this.legs);
        System.out.println(this.nose);
    }
    public static void main(String[] args) {
        OOOps cow1=new OOOps();
        cow1.ear=2;
        cow1.legs=4;
        cow1.nose=1;
        cow1.eat();
        cow1.print();

    }
}
