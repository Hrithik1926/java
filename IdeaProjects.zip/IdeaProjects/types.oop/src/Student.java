public class Student {
    String Name;//This are the propertys.
    int Semester;
    String Enrollment_no;
    String Univeesity;
    int Year;
    String School;
    String Class;
    String Subject;
    String Medium;
    String Board;

    public void study(){
        System.out.println(this.Name);
        System.out.println(this.Enrollment_no);
        System.out.println(this.Semester);
        System.out.println(this.Year);
        System.out.println(this.Univeesity);
        System.out.println("he is doing hard work means he is determinate to their work");

    }
    public void info(){//This is method or known ass Functions
        System.out.println("Name."+" "+this.Name);//this is used to detect the calling  object.According to it print the method on it.
        System.out.println("Class="+" "+this.Class);
        System.out.println("Subject."+" "+this.Subject);
        System.out.println("School."+" "+this.School);
        System.out.println("Medium."+" "+this.Medium);
        System.out.println("Board"+" "+this.Board);
    }

    public static void main(String[] args) {
        Student s1=new Student();//This is the method of creating the Objects or declare the Objects.
        s1.Name="Hritik Meena";
        s1.Enrollment_no="21BTE3CSE10064";
        s1.Semester=3;
        s1.Year=2;
        s1.Univeesity="SAGE University";
        s1.study();//calling the Functions or Methods.
        Student s2=new Student();
       s2.Name="Rupesh Meena";
       s2.Class="Ninth";
       s2.Subject="Maths";
       s2.School="BALBHARTI VIDHYA MANDIR";
       s2.Medium="Medium";
       s2.Board="Mp Board";
       s2.info();
    }
}
