class Outer {
    int age=154;
    String name="2656";
    class Inter{
       public int MyInnter(){
           return age ;
       }
       public String sopa(){
           return name;
       }
   }

        }
public class innerclass_call_outerclass {
    public static void main(String[] args) {
        Outer obj1 = new Outer();
        Outer.Inter obj2 = obj1.new Inter();
        System.out.println(obj2.MyInnter());
        System.out.println(obj2.sopa());
    }
}
